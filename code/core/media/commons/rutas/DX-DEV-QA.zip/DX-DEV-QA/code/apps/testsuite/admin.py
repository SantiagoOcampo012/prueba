from django.contrib import admin
from .models import TestSuite, CasoPrueba, EjecucionPrueba, Entorno


@admin.register(TestSuite)
class TestSuiteAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'proyecto', 'creado_por', 'fecha_modificado')
    list_filter = ('proyecto', 'creado_por')
    search_fields = ('nombre', 'descripcion')
    date_hierarchy = 'fecha_modificado'


@admin.register(Entorno)
class EntornoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'creado_por', 'fecha_modificado')
    list_filter = ('creado_por',)
    search_fields = ('nombre', 'descripcion')
    date_hierarchy = 'fecha_modificado'


@admin.register(CasoPrueba)
class CasoPruebaAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'test_suite', 'estado', 'version', 'entorno', 'creado_por')
    list_filter = ('test_suite', 'estado', 'entorno', 'creado_por')
    search_fields = ('nombre', 'descripcion', 'version')
    date_hierarchy = 'fecha_modificado'


@admin.register(EjecucionPrueba)
class EjecucionPruebaAdmin(admin.ModelAdmin):
    list_display = ('caso_prueba', 'ejecutado_por', 'estado', 'resultado', 'creado_por')
    list_filter = ('estado', 'resultado', 'ejecutado_por', 'creado_por')
    search_fields = ('caso_prueba__nombre', 'resultado', 'observaciones')
    date_hierarchy = 'fecha_modificado'
    readonly_fields = ('ejecutado_por',)
