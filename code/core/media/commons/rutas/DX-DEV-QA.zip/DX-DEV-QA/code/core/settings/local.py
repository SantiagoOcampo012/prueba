from .base import *


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dxdevqa',
        'USER': 'root',
        'PASSWORD': '.Santiago12.',
        'HOST': 'localhost',
        'PORT':'3306',

    }
}

