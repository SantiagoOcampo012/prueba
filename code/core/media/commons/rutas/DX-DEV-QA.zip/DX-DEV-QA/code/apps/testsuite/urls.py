from django.urls import path
from . import views

app_name = 'testsuite'

urlpatterns = [
    # Página principal de TestSuite
    path('', views.TestSuitePageView.as_view(), name='testsuite_page'),
    
    path('testsuite/crear/', views.TestSuiteCreateView.as_view(), name='testsuite_create'),
    path('testsuite/<int:pk>/editar/', views.TestSuiteUpdateView.as_view(), name='testsuite_update'),
    path('testsuite/<int:pk>/eliminar/', views.TestSuiteDeleteView.as_view(), name='testsuite_delete'),
    
    path('caso/crear/', views.CasoPruebaCreateView.as_view(), name='caso_create'),
    path('caso/<int:pk>/editar/', views.CasoPruebaUpdateView.as_view(), name='caso_update'),
    path('caso/<int:pk>/eliminar/', views.CasoPruebaDeleteView.as_view(), name='caso_delete'),
    
    path('ejecucion/crear/', views.EjecucionPruebaCreateView.as_view(), name='ejecucion_create'),
    path('ejecucion/<int:pk>/editar/', views.EjecucionPruebaUpdateView.as_view(), name='ejecucion_update'),
    path('ejecucion/<int:pk>/eliminar/', views.EjecucionPruebaDeleteView.as_view(), name='ejecucion_delete'),
    
    path('entorno/crear/', views.EntornoCreateView.as_view(), name='entorno_create'),
    path('entorno/<int:pk>/editar/', views.EntornoUpdateView.as_view(), name='entorno_update'),
    path('entorno/<int:pk>/eliminar/', views.EntornoDeleteView.as_view(), name='entorno_delete'),
]
