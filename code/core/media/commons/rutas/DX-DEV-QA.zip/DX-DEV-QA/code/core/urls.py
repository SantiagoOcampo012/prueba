from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('apps.autenticacion.urls')),
    path('bugtracker/', include('apps.bugtracker.urls')),
    path('historial/', include('apps.historial.urls')),
    path('notificaciones/', include('apps.notificaciones.urls')),
    path('proyectos/', include('apps.proyectos.urls')),
    path('reports/', include('apps.reports.urls')),
    path('testsuite/', include('apps.testsuite.urls')),
    path('tickets/', include('apps.tickets.urls')),
]
