from django.apps import AppConfig


class TestsuiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.testsuite'
    verbose_name = 'Test Suite'
