default_app_config = 'apps.testsuite.apps.TestsuiteConfig'
