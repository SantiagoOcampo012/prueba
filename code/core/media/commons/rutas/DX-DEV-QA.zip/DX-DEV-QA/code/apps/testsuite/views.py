from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import TemplateView, View
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from .models import TestSuite, CasoPrueba, EjecucionPrueba, Entorno
from apps.proyectos.models import Proyecto
from apps.commons.models import Estado
from .forms import TestSuiteForm, CasoPruebaForm, EjecucionPruebaForm, EntornoForm


class TestSuitePageView(LoginRequiredMixin, TemplateView):
    template_name = 'testsuite/testsuite_page.html'
    login_url = 'login'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Filtros
        proyecto_filter = self.request.GET.get('proyecto', '')
        testsuite_filter = self.request.GET.get('testsuite', '')
        estado_filter = self.request.GET.get('estado', '')
        caso_filter = self.request.GET.get('caso', '')
        tab_active = self.request.GET.get('tab', 'testsuites')
        
        # Obtener datos con filtros
        testsuites = TestSuite.objects.select_related('proyecto').all()
        if proyecto_filter:
            testsuites = testsuites.filter(proyecto_id=proyecto_filter)
        
        casos = CasoPrueba.objects.select_related('test_suite', 'estado', 'entorno').all()
        if testsuite_filter:
            casos = casos.filter(test_suite_id=testsuite_filter)
        if estado_filter:
            casos = casos.filter(estado_id=estado_filter)
        
        ejecuciones = EjecucionPrueba.objects.select_related(
            'caso_prueba', 'ejecutado_por', 'estado', 'archivo'
        ).all()
        if caso_filter:
            ejecuciones = ejecuciones.filter(caso_prueba_id=caso_filter)
        
        # Contexto
        context.update({
            'user': self.request.user,
            'testsuites': testsuites.order_by('-fecha_creacion'),
            'casos': casos.order_by('-fecha_creacion'),
            'ejecuciones': ejecuciones.order_by('-fecha_creacion'),
            'proyectos': Proyecto.objects.all(),
            'estados': Estado.objects.all(),
            'entornos': Entorno.objects.all(),
            'testsuite_form': TestSuiteForm(),
            'caso_form': CasoPruebaForm(),
            'ejecucion_form': EjecucionPruebaForm(),
            'entorno_form': EntornoForm(),
            'proyecto_filter': proyecto_filter,
            'testsuite_filter': testsuite_filter,
            'estado_filter': estado_filter,
            'caso_filter': caso_filter,
            'tab_active': tab_active,
        })
        
        return context


class TestSuiteCreateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        form = TestSuiteForm(request.POST)
        if form.is_valid():
            testsuite = form.save()
            messages.success(request, f'Test Suite "{testsuite.nombre}" creado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page')


class TestSuiteUpdateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        testsuite = get_object_or_404(TestSuite, pk=pk)
        form = TestSuiteForm(request.POST, instance=testsuite)
        if form.is_valid():
            testsuite = form.save()
            messages.success(request, f'Test Suite "{testsuite.nombre}" actualizado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page')


class TestSuiteDeleteView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        testsuite = get_object_or_404(TestSuite, pk=pk)
        nombre = testsuite.nombre
        testsuite.delete()
        messages.success(request, f'Test Suite "{nombre}" eliminado exitosamente')
        return redirect('testsuite:testsuite_page')


class CasoPruebaCreateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        form = CasoPruebaForm(request.POST)
        if form.is_valid():
            caso = form.save()
            messages.success(request, f'Caso de Prueba "{caso.nombre}" creado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=casos')


class CasoPruebaUpdateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        caso = get_object_or_404(CasoPrueba, pk=pk)
        form = CasoPruebaForm(request.POST, instance=caso)
        if form.is_valid():
            caso = form.save()
            messages.success(request, f'Caso de Prueba "{caso.nombre}" actualizado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=casos')


class CasoPruebaDeleteView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        caso = get_object_or_404(CasoPrueba, pk=pk)
        nombre = caso.nombre
        caso.delete()
        messages.success(request, f'Caso de Prueba "{nombre}" eliminado exitosamente')
        return redirect('testsuite:testsuite_page' + '?tab=casos')


class EjecucionPruebaCreateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        form = EjecucionPruebaForm(request.POST)
        if form.is_valid():
            ejecucion = form.save(commit=False)
            ejecucion.ejecutado_por = request.user
            ejecucion.save()
            messages.success(request, 'Ejecución registrada exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=ejecuciones')


class EjecucionPruebaUpdateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        ejecucion = get_object_or_404(EjecucionPrueba, pk=pk)
        form = EjecucionPruebaForm(request.POST, instance=ejecucion)
        if form.is_valid():
            ejecucion = form.save()
            messages.success(request, 'Ejecución actualizada exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=ejecuciones')


class EjecucionPruebaDeleteView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        ejecucion = get_object_or_404(EjecucionPrueba, pk=pk)
        ejecucion.delete()
        messages.success(request, 'Ejecución eliminada exitosamente')
        return redirect('testsuite:testsuite_page' + '?tab=ejecuciones')


class EntornoCreateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        form = EntornoForm(request.POST)
        if form.is_valid():
            entorno = form.save()
            messages.success(request, f'Entorno "{entorno.nombre}" creado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=casos')


class EntornoUpdateView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        entorno = get_object_or_404(Entorno, pk=pk)
        form = EntornoForm(request.POST, instance=entorno)
        if form.is_valid():
            entorno = form.save()
            messages.success(request, f'Entorno "{entorno.nombre}" actualizado exitosamente')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
        return redirect('testsuite:testsuite_page' + '?tab=casos')


class EntornoDeleteView(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request, pk):
        entorno = get_object_or_404(Entorno, pk=pk)
        nombre = entorno.nombre
        entorno.delete()
        messages.success(request, f'Entorno "{nombre}" eliminado exitosamente')
        return redirect('testsuite:testsuite_page' + '?tab=casos')
