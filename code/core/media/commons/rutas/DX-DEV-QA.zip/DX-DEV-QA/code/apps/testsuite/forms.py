from django import forms
from .models import TestSuite, CasoPrueba, EjecucionPrueba, Entorno


class TestSuiteForm(forms.ModelForm):
    class Meta:
        model = TestSuite
        fields = ['nombre', 'descripcion', 'proyecto']
        widgets = {
            'nombre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nombre del Test Suite',
                'required': True
            }),
            'descripcion': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Descripción detallada del Test Suite',
                'rows': 4,
                'required': True
            }),
            'proyecto': forms.Select(attrs={
                'class': 'form-select',
                'required': True
            })
        }
        labels = {
            'nombre': 'Nombre',
            'descripcion': 'Descripción',
            'proyecto': 'Proyecto'
        }


class CasoPruebaForm(forms.ModelForm):
    class Meta:
        model = CasoPrueba
        fields = ['nombre', 'descripcion', 'test_suite', 'estado', 'version', 'entorno']
        widgets = {
            'nombre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nombre del Caso de Prueba',
                'required': True
            }),
            'descripcion': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Descripción del caso de prueba',
                'rows': 4,
                'required': True
            }),
            'test_suite': forms.Select(attrs={
                'class': 'form-select'
            }),
            'estado': forms.Select(attrs={
                'class': 'form-select'
            }),
            'version': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: 1.0.0',
                'required': True
            }),
            'entorno': forms.Select(attrs={
                'class': 'form-select'
            })
        }
        labels = {
            'nombre': 'Nombre',
            'descripcion': 'Descripción',
            'test_suite': 'Test Suite',
            'estado': 'Estado',
            'version': 'Versión',
            'entorno': 'Entorno'
        }


class EjecucionPruebaForm(forms.ModelForm):
    class Meta:
        model = EjecucionPrueba
        fields = ['caso_prueba', 'estado', 'resultado', 'observaciones', 'archivo']
        widgets = {
            'caso_prueba': forms.Select(attrs={
                'class': 'form-select',
                'required': True
            }),
            'estado': forms.Select(attrs={
                'class': 'form-select'
            }),
            'resultado': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Ej: Exitoso, Fallido, Bloqueado',
                'required': True
            }),
            'observaciones': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Observaciones sobre la ejecución (opcional)',
                'rows': 4
            }),
            'archivo': forms.Select(attrs={
                'class': 'form-select'
            })
        }
        labels = {
            'caso_prueba': 'Caso de Prueba',
            'estado': 'Estado',
            'resultado': 'Resultado',
            'observaciones': 'Observaciones',
            'archivo': 'Archivo Adjunto'
        }


class EntornoForm(forms.ModelForm):
    class Meta:
        model = Entorno
        fields = ['nombre', 'descripcion']
        widgets = {
            'nombre': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Nombre del Entorno',
                'required': True
            }),
            'descripcion': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Descripción del entorno',
                'rows': 3,
                'required': True
            })
        }
        labels = {
            'nombre': 'Nombre',
            'descripcion': 'Descripción'
        }
